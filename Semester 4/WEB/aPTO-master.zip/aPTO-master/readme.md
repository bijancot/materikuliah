# <strong><em>aPTO</em></strong>
### <strong><em>(aplikasi pembayaran tagihan online)</em></strong>

<em>aplikasi pembayaran tagihan online (aPTO)</em> or in english called Online bill payment application is an apps that focused to help small businesses to manage their payment system to be more and more efficient and effective than conventional system.

In Indonesia we recenty moved to the  real digital era with easier way to pay something with something like e-wallet apps. But in some sector this payment method not yet supported. aPTO will change this condition with a cheap apps that support almost every payment method for small businesses in Indonesia.

built with :
- PHP7 & HTML5
- Docker
- Apache over docker
- MySQL over docker
- Bulma css [**bulma.io**](https://bulma.io/)

## <strong><em>How aPTO works?</em></strong>

[there should be a diagram (ASAP)]

In general aPTO will have backend for admin & staff on the small business and frontend for users who have bills to that small business.

Let's say that you have a services that provided by baba company, so if it's  times to pay bill for that service, staff on baba company will make an invoice for you and tell you how to pay it. After you pay baba company's staff will check your payment.

## <strong><em>What currently we work on?</em></strong>
 - we  work's for good grade in this class (Lol)
 - designing with bulma css
##### Copyright &copy; 2019 Panji Iman Baskoro [**panjibaskoro.web.id**](https://panjibaskoro.web.id/)
